part of native_video_view;

/// Enum to specify the types of controls in the media controller.
enum _MediaControl {
  pause,
  play,
  stop,
  fwd,
  rwd,
  toggle_sound,
}
