#import <Flutter/Flutter.h>

@interface NativeVideoViewPlugin : NSObject<FlutterPlugin>
@end
